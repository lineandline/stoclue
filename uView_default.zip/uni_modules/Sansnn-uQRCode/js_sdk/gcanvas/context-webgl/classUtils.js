export function getTransferedObjectUUID(name, id) {
    return `${name.toLowerCase()}-${id}`;
}