module.exports = {
  externalRegister: require('./register'),
  externalLogin: require('./login'),
  updateUserInfoByExternal: require('./update-user-info')
}
