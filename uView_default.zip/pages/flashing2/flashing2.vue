<template>
	<view>
		<canvas id="myCanvas" type="2d" :style="{width: '100vw', height: '100vh'}"></canvas>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				canvas: null,
				ctx: null,
				barrageArr: [

					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 ,
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2 
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2
					},
					{
						text: "弹幕内容",
						color: "#ff0000",
						x: 100, 
						y: 200,
						speed: 2
					}


				], // 存储弹幕的数组
				density: 0.05, // 设定弹幕密度
				speed: 2, // 设定弹幕速度
			}
		},
		mounted() {
			this.canvas = uni.createSelectorQuery().select('#myCanvas');
			this.canvas.width = uni.getSystemInfoSync().windowWidth;
			this.canvas.height = uni.getSystemInfoSync().windowHeight;
			this.ctx = this.canvas.getContext('2d');
			// 设置字体和字号
			this.ctx.font = 'bold 16px Arial';
			this.ctx.textBaseline = 'bottom';
			this.ctx.textAlign = 'left';
			// 开始动画
			this.startAnimate();
		},
		startAnimate() {
			setInterval(() => {
				// 清除画布
				this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
				// 绘制弹幕并更新位置
				for (let i = 0; i < this.barrageArr.length; i++) {
					let barrage = this.barrageArr[i];
					barrage.x -= barrage.speed;
					this.ctx.fillStyle = barrage.color;
					this.ctx.fillText(barrage.text, barrage.x, barrage.y);
					if (barrage.x < -this.ctx.measureText(barrage.text).width) {
						this.barrageArr.splice(i, 1);
						i--;
					}
				}
				// 添加新弹幕
				if (Math.random() < this.density) {
					let barrage = {
						text: this.getRandomText(5, 10),
						color: this.getRandomColor(),
						x: this.canvas.width,
						y: this.getRandomY(),
						speed: this.speed,
					};
					this.barrageArr.push(barrage);
				}
			}, 30);
		},
		methods: {
			// 获取一个随机颜色
			getRandomColor() {
				return '#' + Math.floor(Math.random() * 16777215).toString(16);
			},
			// 获取一个随机Y坐标
			getRandomY() {
				return Math.floor(Math.random() * this.canvas.height);
			},
			// 获取一个随机字符串
			getRandomText(minLength, maxLength) {
				let str = '';
				let length = Math.floor(Math.random() * (maxLength - minLength + 1) + minLength);
				for (let i = 0; i < length; i++) {
					str += String.fromCharCode(65 + Math.floor(Math.random() * 26));
				}
				return str;
			},
		}
	}
</script>

<style>

</style>