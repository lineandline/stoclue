<template>
	<view class="cart">
		<view class="bullet">
			<canvas style="width:2800rpx;height:1500rpx" canvas-id="bulletCanvas"></canvas>
		</view>
		<view class="input-container">
			<u-form :model="bullet" ref="uForm">
				<u-form-item label=":::" label-width="150" prop="bullet" left-icon="account">
					<u-input placeholder="请输入您的留言" v-model="bullet.bullet" type="text"
						style="border: 2px solid #808080;border-radius: 10px;"></u-input>
					<u-button class="submit-button" @click="submit">提交</u-button>
				</u-form-item>
			</u-form>
		</view>
	</view>
</template>

<script>
	// const canvas = uni.createSelectorQuery().select('#bulletCanvas');
	export default {
		data() {
			return {
				bullet: [{
						bullet: "内容1"
					},
					{
						bullet: "内容2"
					},
					{
						bullet: "内容3"
					},
					{
						bullet: "内容4"
					},
					{
						bullet: "内容5"
					},
					{
						bullet: "内容6"
					},
					{
						bullet: "内容7"
					},
					{
						bullet: "内容8"
					},
					{
						bullet: "内容9"
					},
					{
						bullet: "内容1"
					},
					{
						bullet: "内容2"
					},
					{
						bullet: "内容3"
					},
					{
						bullet: "内容4"
					},
					{
						bullet: "内容5"
					},
					{
						bullet: "内容6"
					},
					{
						bullet: "内容7"
					},
					{
						bullet: "内容8"
					},
					{
						bullet: "内容9"
					},
					{
						bullet: "内容1"
					},
					{
						bullet: "内容2"
					},
					{
						bullet: "内容3"
					},
					{
						bullet: "内容4"
					},
					{
						bullet: "内容5"
					},
					{
						bullet: "内容6"
					},
					{
						bullet: "内容7"
					},
					{
						bullet: "内容8"
					},
					{
						bullet: "内容9"
					},
					{
						bullet: "内容1"
					},
					{
						bullet: "内容2"
					},
					{
						bullet: "内容3"
					},
					{
						bullet: "内容4"
					},
					{
						bullet: "内容5"
					},
					{
						bullet: "内容6"
					},
					{
						bullet: "内容7"
					},
					{
						bullet: "内容8"
					},
					{
						bullet: "内容9"
					}
				]
			}
		},
		onLoad() {
			this.loadData(true);
			var that = this
			// 获取留言数据
			uni.request({
				url: 'http://192.168.1.208:8080/',
				method: "POST",
				data: {
					bullet: '',
				},
				success: function(res) {
					const messages = res.data; // 获取到的留言数据

					// 将留言数据转换为弹幕数据格式
					const bullets = messages.map(message => {
						return {
							bullet: message.content
						};
					});

					that.bullet = bullets; // 将弹幕数据赋值给 bullet 数组
					console.log(that.bullet);
				},
			})

		},
		onReady() {

			this.order()
				.then(() => {
					this.draw()
				})
		},
		methods: {
			submit: function() {
				const bulletData = this.bullet.bullet;
				uni.request({
					url: 'http://192.168.1.208:8086/', // 服务端提供的登录处理接口地址。
					method: 'POST',
					//默认get 转换后 text=uni.request   参数名必须与后台的函数参数名对应
					data: {
						bullet: bulletData
					},
					//成功的处理函数 res为响应结果对象 data为后台返回的数据
					//=> 将vue对象传递到函数中
					success(res) {
						// 请求成功的回调处理
						console.log('提交成功');
						// 可以根据后台返回的数据进行相应的处理
						console.log(res.data);
					},
					fail(res) {
						// 请求失败的回调处理
						console.error('提交失败');
						console.error(res);
					}
				});
			},


			// 整理数据
			order() {
				return new Promise((resolve, reject) => {
					resolve(
						// this.bullet = this.bullet.map(item => {
						// 	return Object.assign(item, {
						// 		speed: Math.random() * 1 + 2,
						// 		x: Math.random() * 1000 + 600,
						// 		y: Math.random() * 600 + 20
						// 	})
						// })
					)
				})
			},
			draw() {
				const ctx = uni.createCanvasContext("bulletCanvas")

				function anim() {
					ctx.setFontSize(20)
					// 擦除整个画布
					ctx.clearRect(0, 0, 1700, 1000)
					// 循环绘制
					ctx.font = 'bold 20px "Arial Rounded MT Bold"'; // 设置字体加粗
					// ctx.lineWidth = 2; // 设置边框宽度
					// ctx.strokeStyle = 'black'; // 设置边框颜色
					this.bullet.forEach(item => {

						// let color = getRandomColor();
						ctx.setFillStyle(item.color); // 设置填充颜色
						// drawTextWithBorder(ctx, item.bullet, item.x, item.y, "#000000", 2);
						// 调用measureText()来获取TextMertics对象
						let textMertics = ctx.measureText(item.bullet)
						// 根据TextMertics对象获取文字宽度
						let textWidth = textMertics.width



						let rectX = item.x;
						let rectY = item.y - 20; // 调整矩形框的位置以适应文字
						let rectWidth = textWidth + 10; // 调整矩形框的宽度以适应文字
						let rectHeight = 30; // 调整矩形框的高度以适应文字
						let borderRadius = 15; // 调整圆角半径大小

						// 绘制圆角矩形边框
						ctx.beginPath();
						ctx.setLineWidth(1); // 设置边框线条宽度为2像素
						ctx.setStrokeStyle("#CCCCCC"); // 设置边框描边颜色为浅灰色

						ctx.moveTo(rectX + borderRadius, rectY);
						ctx.lineTo(rectX + rectWidth - borderRadius, rectY);
						ctx.arcTo(rectX + rectWidth, rectY, rectX + rectWidth, rectY + borderRadius, borderRadius);
						ctx.lineTo(rectX + rectWidth, rectY + rectHeight - borderRadius);
						ctx.arcTo(rectX + rectWidth, rectY + rectHeight, rectX + rectWidth - borderRadius, rectY +
							rectHeight, borderRadius);
						ctx.lineTo(rectX + borderRadius, rectY + rectHeight);
						ctx.arcTo(rectX, rectY + rectHeight, rectX, rectY + rectHeight - borderRadius,
							borderRadius);
						ctx.lineTo(rectX, rectY + borderRadius);
						ctx.arcTo(rectX, rectY, rectX + borderRadius, rectY, borderRadius);
						ctx.closePath();
						ctx.stroke();



						ctx.fillText(item.bullet, item.x + 5, item.y)



						item.x -= item.speed
						// 当弹幕滚动到画布之外的时候，再次回到右边
						if (item.x < -textWidth) {
							item.x = 1700
						}
					})
					ctx.draw()
					requestAnimationFrame(anim.bind(this))
				}
				this.bullet = this.bullet.map(item => {
					return Object.assign(item, {
						speed: Math.random() * 1 + 2,
						x: Math.random() * 1000 + 500,
						y: Math.random() * 800 + 30,
						color: getRandomColor() // 为每条弹幕生成随机颜色并赋值给color属性
					});
				});
				// anim.call(this)
				function getRandomColor() {
					let letters = "0123456789ABCDEF";
					let color = "#";

					for (let i = 0; i < 6; i++) {
						color += letters[Math.floor(Math.random() * 16)];
					}

					return color;
				}


				anim.call(this)
			}

		}
	}
</script>

<style>
	/* .bullet {
	  border: 1px solid #000;
	  padding: 5px;
	} */
	.cart {
		/* background-image: -moz-element(); */
		background-color: aliceblue;
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		height: 100vh;
		width: 100vw;
		/* background-image: url(""); */
		background-repeat: no-repeat;
		background-size: cover;
	}

	.u-form-item {
		width: 1200px;
		/* 调整输入框的宽度 */
	}

	.input-container {
		display: flex;
		justify-content: center;
	}

	.submit-button {
		background-color: #808080;
		/* 输入框的背景色 */
		color: #FFFFFF;
		/* 输入框的文字颜色 */
		border-radius: 5px;
		/* 输入框的圆角半径 */
		padding: 10px 20px;
		/* 输入框的内边距 */
		margin-top: 0px;
		/* 调整按钮与输入框之间的间距 */
	}
</style>