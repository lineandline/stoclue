<template>
	<view class="tve">
		<view class="content">
			<time-line ref="timeline" location="left"></time-line>
		</view>
	</view>
</template>
<script>
	import timeLine from '../../components/xuan-timeLine/xuan-timeLine.vue'
	export default {
		components: {
			timeLine
		},
		data() {
			return {
				time: 0,
				isclick: true,
			};
		},
		onLoad() {

		},
		onPageScroll() {
			if (this.isclick) {
				this.timer();
				this.$refs.timeline.getScroll();
			}
		},
		onReady() {

		},
		methods: {
			timer() {
				if (this.time > 0) {
					this.isclick = false;
					this.time--;
					setTimeout(this.timer, 1)
				} else {
					this.isclick = true;
					this.time = 10
				}
			}

		}
	};
</script>

<style lang="scss" scoped>
	.tve {
		float: right;
		width: 1850rpx;
		height: 2600rpx;
		margin-top: 20rpx;
		margin-right: 600rpx;
		// background-color: #777799;
	}

</style>