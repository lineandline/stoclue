<!-- 账号注册页 -->
<template>
	<view class="uni-content">
		<match-media :min-width="370">
			<view class="login-logo">
				<image :src="logo"></image>
			</view>
			<!-- 顶部文字 -->
			<text class="title title-box">用户名密码注册</text>
		</match-media>
		<u-form  :model="formData"  >
			<u-form-item name="username" prop="username" required>
				<u-input  :focus="focusUsername" @blur="focusUsername = false"
					class="input-box" placeholder="请输入用户名" v-model="formData.username"  />
			</u-form-item>
			<u-form-item name="realName" prop="realName">
				<u-input  :focus="focusNickname" @blur="focusNickname = false"
					class="input-box" placeholder="请输入用户昵称" v-model="formData.realName"  />
			</u-form-item>
			<u-form-item name="password" prop="password"  required>
				<u-input  :focus="focusPassword" @blur="focusPassword = false"
					class="input-box" maxlength="20"
					:placeholder="'请输入' + '8' + '-16位密码'" type="password"
					v-model="formData.password"  />
			</u-form-item>
			<u-form-item name="password2" prop="password2"  required>
				<u-input  :focus="focusPassword2" @blur="focusPassword2 =false"
					class="input-box" placeholder="再次输入密码" maxlength="20" type="password" v-model="formData.password2"
					 />
			</u-form-item>
			
			<button class="uni-btn" type="primary" @click="submit">注册</button>
			<button @click="navigateBack" class="register-back">返回</button>
			<match-media :min-width="375">
				<view class="link-box">
					<text class="link" >邮箱验证码注册</text>
					<text class="link" @click="toLogin">已有账号？点此登录</text>
				</view>
			</match-media>
		</u-form>
		<view>
			<u-toast ref="uToast" />
		</view>
	</view>
</template>

<script>

	export default {

		data() {
			return {
				formData: {
					username: "",
					realName: "",
					password: "",
					password2: "",
					captcha: ""
				},

				focusUsername: false,
				focusNickname: false,
				focusPassword: false,
				focusPassword2: false,
				logo: "/static/logo.png"
			}
		},
		onReady() {

		},
		onShow() {
			
		},
		methods: {
			/**
			 * 触发表单提交
			 */
			submit() {
				
					uni.request({
						url: 'http://192.168.1.73:8080/user/save', // 服务端提供的登录处理接口地址。
						method:'POST',
						//post   参数名必须与后台的函数参数的属性名对应  即 前端 {username:...}（与接口工具测试一样格式） 服务端 @ResponseBody 封装对象 
						data: this.formData  ,
						//成功的处理函数 res为响应结果对象 data为后台返回的数据
						//=> 将vue对象传递到函数中
						success: (res) => {
							if(res.data.success){
								this.$refs.uToast.show({
									title: '注册成功',
									type: 'success',
									url: '/pages/login/login'
								})
								
							}else{
								this.$refs.uToast.show({
									title: '注册失败',
									type: 'fail'
								})
							}
						},
						fail: function(res){
							// console.log(res);
							this.$refs.uToast.show({
								title: res.errMsg,
								type: 'fail'
							})
						}
					});
				
			},
			navigateBack() {
				uni.navigateBack()
			},
			toLogin() {
				uni.navigateTo({
					url: '/pages/login/login'
				})
			}
		}
	}
</script>

<style lang="scss">

	@media screen and (max-width: 690px) {
		.uni-content {
			margin-top: 15px;
			height: 100%;
			background-color: #fff;
		}
	}

	@media screen and (min-width:375px) {
		.uni-content {
			padding: 30px 40px 60px;
			max-height: 530px;
		}

		.link-box {
			/* #ifndef APP-NVUE */
			display: flex;
			/* #endif */
			flex-direction: row;
			justify-content: space-between;
			margin-top: 10px;
		}

		.link {
			font-size: 12px;
		}
	}

	.uni-content ::v-deep .u-form-item__label {
		position: absolute;
		left: -15px;
	}

	button {
		margin-top: 15px;
	}
	
	.uni-content {
	  padding: 0 60rpx;
	}
	
	
	
	.title {
	  /* #ifndef APP-NVUE */
	  display: flex;
	  /* #endif */
	  padding: 18px 0;
	  font-weight: 800;
	  flex-direction: column;
	}
</style>

