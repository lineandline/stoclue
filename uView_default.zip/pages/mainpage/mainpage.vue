<template>
	<view class="index">
		<!-- 状态栏高度 占位 | 开始 -->
		<view class="ZhuangTaiLan-GaoDu"></view>
		<!-- 状态栏高度 占位 | 结束 -->
		
		<!-- 如果，有内容 | 开始 -->
		<template v-if="YR_QuKuai_Markdown_BianJiQi_QuKuai.length">
			<view class="QuKuai" v-for="(item,index) in YR_QuKuai_Markdown_BianJiQi_QuKuai" :key="item.id">
				<!-- 编辑 与 显示区域 | 开始 -->
				<view class="textarea">
					<!-- P 标签 | 开始 -->
					<textarea
						v-if="item.LeiXing == 'P'"
						class="textarea-P"
						:focus="true"
						maxlength="-1"
						auto-height="true"
						:value="item.NeiRong"
						@input="HuoQu_XiangYingShi_NeiRong($event,item)">
					</textarea>
					<!-- P 标签 | 结束 -->
					
					<!-- H1 - H6 标签 | 开始 -->
					<textarea
						v-if="item.LeiXing == 'H1'"
						class="textarea-H1"
						:focus="true"
						maxlength="-1"
						auto-height="true"
						:value="item.NeiRong"
						@input="HuoQu_XiangYingShi_NeiRong($event,item)">
					</textarea>
					<textarea
						v-if="item.LeiXing == 'H2'"
						class="textarea-H2"
						:focus="true"
						maxlength="-1"
						auto-height="true"
						:value="item.NeiRong"
						@input="HuoQu_XiangYingShi_NeiRong($event,item)">
					</textarea>
					<textarea
						v-if="item.LeiXing == 'H3'"
						class="textarea-H3"
						:focus="true"
						maxlength="-1"
						auto-height="true"
						:value="item.NeiRong"
						@input="HuoQu_XiangYingShi_NeiRong($event,item)">
					</textarea>
					<textarea
						v-if="item.LeiXing == 'H4'"
						class="textarea-H4"
						:focus="true"
						maxlength="-1"
						auto-height="true"
						:value="item.NeiRong"
						@input="HuoQu_XiangYingShi_NeiRong($event,item)">
					</textarea>
					<textarea
						v-if="item.LeiXing == 'H5'"
						class="textarea-H5"
						:focus="true"
						maxlength="-1"
						auto-height="true"
						:value="item.NeiRong"
						@input="HuoQu_XiangYingShi_NeiRong($event,item)">
					</textarea>
					<textarea
						v-if="item.LeiXing == 'H6'"
						class="textarea-H6"
						:focus="true"
						maxlength="-1"
						auto-height="true"
						:value="item.NeiRong"
						@input="HuoQu_XiangYingShi_NeiRong($event,item)">
					</textarea>
					<!-- H1 - H6 标签 | 开始 -->
					
					<!-- blockquote 标签 | 开始 -->
					<textarea
						v-if="item.LeiXing == 'YinYong'"
						class="textarea-YinYong"
						:focus="true"
						maxlength="-1"
						auto-height="true"
						:value="item.NeiRong"
						@input="HuoQu_XiangYingShi_NeiRong($event,item)">
					</textarea>
					<!-- blockquote 标签 | 结束 -->
					
					<!-- pre-code 与 li 标签 | 开始 -->
					<textarea
						v-if="item.LeiXing == 'DaiMa'"
						class="textarea-DaiMa"
						:focus="true"
						maxlength="-1"
						auto-height="true"
						:value="item.NeiRong"
						@input="HuoQu_XiangYingShi_NeiRong($event,item)">
					</textarea>
					<textarea
						v-if="item.LeiXing == 'LieBiao'"
						class="textarea-LieBiao"
						:focus="true"
						maxlength="-1"
						auto-height="true"
						:value="item.NeiRong"
						@input="HuoQu_XiangYingShi_NeiRong($event,item)">
					</textarea>
					<!-- pre-code 与 li 标签 | 结束 -->
					
					<!-- 图片 与 视频 标签 | 开始 -->
					<view
						class="textarea-TuPian"
						v-if="item.LeiXing == 'TuPian'">
						<image :src="item.NeiRong" mode="widthFix"></image>
					</view>
					<view
						class="textarea-ShiPin"
						v-if="item.LeiXing == 'ShiPin'">
						<video :src="item.NeiRong"></video>
					</view>
					<!-- 图片 与 视频 标签 | 结束 -->
				</view>
				<!-- 编辑 与 显示区域 | 结束 -->
				
				<!-- 输入框下的基本样式插入按钮 | 开始 -->
				<view class="CaoZuoQu">
					<!-- 区块位置调整 | 上 -->
					<text
						@click="DianJi_ShangXia_PaiXu('Shang', index)"
						class="iconfont icon-arrow-up-filling"></text>
						
					<!-- 区块位置调整 | 下 -->
					<text
						@click="DianJi_ShangXia_PaiXu('Xia', index)"
						class="iconfont icon-arrow-down-filling"></text>
						
					<!-- 插入 HTML 标签 | 开始 -->
					<text
						@click="DianJi_KuaiNei_ChaRu_ChangYong_HTML('<b>粗体</b>',index)"
						class="Zi"
						style="font-weight:bold;">粗</text>
					<text
						@click="DianJi_KuaiNei_ChaRu_ChangYong_HTML('<i>斜体</i>',index)"
						class="Zi"
						style="font-style:italic">斜</text>
					<text
						@click="DianJi_KuaiNei_ChaRu_ChangYong_HTML('<u>下</u>',index)"
						class="Zi"
						style="text-decoration:underline;">下划线</text>
					<text
						@click="DianJi_KuaiNei_ChaRu_ChangYong_HTML('<del>删除线</del>',index)"
						class="Zi"
						style="text-decoration:line-through;">删除线</text>
					<!-- 插入 HTML 标签 | 结束 -->
					
					<!-- 删除当前区块 -->
					<text
						@click="DianJi_ShanChu_Ben_Kuai(index)"
						class="iconfont icon-delete-filling"></text>
				</view>
				<!-- 输入框下的基本样式插入按钮 | 结束 -->
				
				<!-- 插入内容类型按钮 | 开始 -->
				<view class="ChaRuQu">
					<view class="ChaRuQu-Zuo">插入</view>
					<view class="ChaRuQu-Zhong">
						<scroll-view scroll-x="true">
							<view class="ChaRuQu-Zhong-AnNiu">
								
								<!-- 插入段落 | <p> 标签 -->
								<view
									@click="DianJi_ChaRu_DuanLuo(index)"
									hover-class="Hover"
									hover-stay-time="100"
									class="TuBiao-Zi">段
								</view>
								
								<!-- 插入段落 | <H*> 系列标签 | 弹出框，选择 h1 - h6 -->
								<view
									@click="DianJi_ChaRu_BiaoTi(index)"
									hover-class="Hover"
									hover-stay-time="100"
									class="TuBiao-Zi">标
								</view>
								
								<!-- 插入引用 | <blockquote> 标签 -->
								<view
									@click="DianJi_ChaRu_YinYong(index)"
									hover-class="Hover"
									hover-stay-time="100"
									class="TuBiao-Zi">引
								</view>
								
								<!-- 插入引用 | <pre><code> 标签 -->
								<view
									@click="DianJi_ChaRu_DaiMa(index)"
									hover-class="Hover"
									hover-stay-time="100"
									class="TuBiao-Zi">代
								</view>
								
								<!-- 插入引用 | <li> 标签 -->
								<view
									@click="DianJi_ChaRu_LieBiao(index)"
									hover-class="Hover"
									hover-stay-time="100"
									class="TuBiao-Zi">列
								</view>
								
								<!-- 插入图片 | 打开图片拍摄、上传 -->
								<view
									@click="DianJi_ChaRu_TuPian(index)"
									hover-class="Hover"
									hover-stay-time="100"
									class="iconfont icon-tupian">
								</view>
								
								<!-- 插入视频 | 打开视频拍摄、上传 -->
								<view
									@click="DianJi_ChaRu_ShiPin(index)"
									hover-class="Hover"
									hover-stay-time="100"
									class="iconfont icon-zhibo">
								</view>
							</view>
						</scroll-view>
					</view>
					<view class="ChaRuQu-You">
						<view class="iconfont icon-arrow-double-right"></view>
					</view>
				</view>
				<!-- 插入内容类型按钮 | 结束 -->
			</view>
			
			<!-- 尾部悬浮框 | 开始 -->
			<view style="width: 100%;height:80rpx;"></view>
			<view class="WeiBu-AnNiu">
				<view class="Zuo">
					<text
						class="ZuoQingKong"
						@click="DianJi_QingKong_DangQian">清空当前</text>
					<text class="ZuoTiShi">点击确认编辑 或 手机返回键</text>
				</view>
				<view
					class="You"
					@click="DianJi_QueRen_BianJi">确认编辑</view>
			</view>
			<!-- 尾部悬浮框 | 结束 -->
		</template>
		<!-- 如果，有内容 | 结束 -->
		
		<!-- 如果，没有内容 | 开始 -->
		<template v-else>
			<view class="RuGuo-MeiYou-QuKuai">
				<view class="_TiShi">
					<text class="iconfont icon-yinyong"></text>
					<view>当前没有任何内容，请点击以下按钮添加内容区块。</view>
				</view>
				<view class="_Kuai">
					<view class="XunHuan" @click="DianJi_ChaRu_DuanLuo(0)">段落</view>
					<view class="XunHuan" @click="DianJi_ChaRu_BiaoTi(0)">标题</view>
					<view class="XunHuan" @click="DianJi_ChaRu_YinYong(0)">引用</view>
					<view class="XunHuan" @click="DianJi_ChaRu_DaiMa(0)">代码</view>
					<view class="XunHuan" @click="DianJi_ChaRu_LieBiao(0)">列表</view>
					<view class="XunHuan" @click="DianJi_ChaRu_TuPian(0)">图片</view>
					<view class="XunHuan" @click="DianJi_ChaRu_ShiPin(0)">视频</view>
					<!-- <view class="XunHuan">录音</view> -->
				</view>
			</view>
		</template>
		<!-- 如果，没有内容 | 结束 -->
	</view>
</template>

<script>
	export default {
		data() {
			return {
				YR_QuKuai_Markdown_BianJiQi_QuKuai:[], // 区块列表
			}
		},
		onLoad() {

		},
		methods: {
			// 点击，插入，图片
			DianJi_ChaRu_TuPian(index){
				uni.chooseImage({
					count: 1, // 限制1次只能选择1张
					success: (res) => {
						uni.showLoading({title: "图片上传中"});
						let ls = res.tempFiles;
						this.DianJi_ChaRu_TuPian_ShangChuan(ls[0].path,index);
					}
				})
			},
			// 图片上传 逻辑
			DianJi_ChaRu_TuPian_ShangChuan(e,index){
				// 这里只是模拟，实际情况因该这里先上传，以下由wordpress的demo做参考
				// 模拟数据 开始
				let TuPianURL = e;
				this.YR_QuKuai_Markdown_BianJiQi_QuKuai.splice(index + 1, 0, {
					LeiXing: "TuPian",
					id: this.uuid(),
					NeiRong: TuPianURL
				});
				uni.hideLoading();
				// 模拟数据 结束
				
				// demo参考 开始
				// let TuPianURL = e;
				// uni.uploadFile({
				// 	url: "/wp-json/wp/v2/media",
				// 	filePath: TuPianURL,
				// 	name: "file",
				// 	header: {
				// 		'Authorization': 'Bearer ' + 'token'
				// 	},
				// 	success: (res) => {
				// 		let a = JSON.parse(res.data)
				// 		let img = a.guid.rendered;
						
				// 		this.YR_QuKuai_Markdown_BianJiQi_QuKuai.splice(index + 1, 0, {
				// 			LeiXing: "TuPian",
				// 			id: this.uuid(),
				// 			NeiRong: img
				// 		});
						
				// 		uni.hideLoading();
				// 	}
				// })
				// demo参考 结束
			},
			// 点击，插入，视频
			DianJi_ChaRu_ShiPin(index){
				uni.chooseVideo({
					sourceType: ['camera', 'album'],
					success: (res) => {
						uni.showLoading({title: "视频上传中"});
						this.DianJi_ChaRu_ShiPin_ShangChuan(res.tempFilePath,index)
					}
				});
			},
			// 视频上传 逻辑
			DianJi_ChaRu_ShiPin_ShangChuan(e,index){
				// 这里只是模拟，实际情况因该这里先上传，以下由wordpress的demo做参考
				// 模拟数据 开始
				let ShiPinURL = e;
				this.YR_QuKuai_Markdown_BianJiQi_QuKuai.splice(index + 1, 0, {
					LeiXing: "ShiPin",
					id: this.uuid(),
					NeiRong: ShiPinURL
				});
				uni.hideLoading();
				// 模拟数据 结束
				
				// demo 开始
				// let ShiPinURL = e;
				// uni.uploadFile({
				// 	url: "/wp-json/wp/v2/media",
				// 	filePath: ShiPinURL,
				// 	name: "file",
				// 	header: {
				// 		'Authorization': 'Bearer ' + 'token'
				// 	},
				// 	success: (res) => {
				// 		uni.hideLoading();
				// 		let a = JSON.parse(res.data)
				// 		let video = a.guid.rendered;
				// 		this.YR_QuKuai_Markdown_BianJiQi_QuKuai.splice(index + 1, 0, {
				// 			LeiXing: "ShiPin",
				// 			id: this.uuid(),
				// 			NeiRong: video
				// 		});
				// 	}
				// })
				// demo 结束
			},
			// 点击，块内，插入，常用，HTML
			DianJi_KuaiNei_ChaRu_ChangYong_HTML(e,index){
				this.YR_QuKuai_Markdown_BianJiQi_QuKuai[index].NeiRong += e
			},
			// 点击，插入，段落
			DianJi_ChaRu_DuanLuo(index){
				this.YR_QuKuai_Markdown_BianJiQi_QuKuai.splice(index + 1, 0, {
					LeiXing: "P",
					id: this.uuid(),
					NeiRong: ""
				});
			},
			// 点击，插入，代码
			DianJi_ChaRu_DaiMa(index){
				this.YR_QuKuai_Markdown_BianJiQi_QuKuai.splice(index + 1, 0, {
					LeiXing: "DaiMa",
					id: this.uuid(),
					NeiRong: ""
				});
			},
			// 点击，插入，标题落
			DianJi_ChaRu_BiaoTi(index){
				uni.showActionSheet({
					itemList: ['一级标题','二级标题','三级标题','四级标题','五级标题','六级标题'],
					success: (res) => {
						if(res.tapIndex === 0){
							this.YR_QuKuai_Markdown_BianJiQi_QuKuai.splice(index + 1, 0, {
								LeiXing: "H1",
								id: this.uuid(),
								NeiRong: ""
							});
						}
						if(res.tapIndex === 1){
							this.YR_QuKuai_Markdown_BianJiQi_QuKuai.splice(index + 1, 0, {
								LeiXing: "H2",
								id: this.uuid(),
								NeiRong: ""
							});
						}
						if(res.tapIndex === 2){
							this.YR_QuKuai_Markdown_BianJiQi_QuKuai.splice(index + 1, 0, {
								LeiXing: "H3",
								id: this.uuid(),
								NeiRong: ""
							});
						}
						if(res.tapIndex === 3){
							this.YR_QuKuai_Markdown_BianJiQi_QuKuai.splice(index + 1, 0, {
								LeiXing: "H4",
								id: this.uuid(),
								NeiRong: ""
							});
						}
						if(res.tapIndex === 4){
							this.YR_QuKuai_Markdown_BianJiQi_QuKuai.splice(index + 1, 0, {
								LeiXing: "H5",
								id: this.uuid(),
								NeiRong: ""
							});
						}
						if(res.tapIndex === 5){
							this.YR_QuKuai_Markdown_BianJiQi_QuKuai.splice(index + 1, 0, {
								LeiXing: "H6",
								id: this.uuid(),
								NeiRong: ""
							});
						}
					}
				});
			},
			// 点击，插入，引用
			DianJi_ChaRu_YinYong(index){
				this.YR_QuKuai_Markdown_BianJiQi_QuKuai.splice(index + 1, 0, {
					LeiXing: "YinYong",
					id: this.uuid(),
					NeiRong: ""
				});
			},
			// 点击，插入，列表
			DianJi_ChaRu_LieBiao(index){
				this.YR_QuKuai_Markdown_BianJiQi_QuKuai.splice(index + 1, 0, {
					LeiXing: "LieBiao",
					id: this.uuid(),
					NeiRong: ""
				});
			},
			// 点击，上下，排序
			DianJi_ShangXia_PaiXu(FangXiang, index) {
				const BianJi = this.YR_QuKuai_Markdown_BianJiQi_QuKuai.splice(index, 1)[0];
				const _index = {
					Shang: index - 1,
					Xia: index + 1
				} [FangXiang];
				this.YR_QuKuai_Markdown_BianJiQi_QuKuai.splice(_index, 0, BianJi);
			},
			// 点击，删除，本，块
			DianJi_ShanChu_Ben_Kuai(index) {
				uni.showModal({
					title: "注意",
					content: "确定删除本块吗？本操作不可恢复，请谨慎操作。",
					success: (res) => {
						if(res.confirm) {
							this.YR_QuKuai_Markdown_BianJiQi_QuKuai.splice(index, 1);
						}
					}
				});
			},
			// 获取，响应式，内容
			HuoQu_XiangYingShi_NeiRong(e, item) {
				this.$set(item, 'NeiRong', e.target.value);
			},
			// 点击，清空，当前
			DianJi_QingKong_DangQian(){
				uni.showModal({
					title: "注意",
					content: "确定清空所有吗？本操作不可恢复，请谨慎操作。",
					success: (res) => {
						if(res.confirm) {
							this.YR_QuKuai_Markdown_BianJiQi_QuKuai = [];
						}
					}
				});
			},
			// 点击，确认，编辑
			DianJi_QueRen_BianJi(){
				let NeiRong = "";
				this.YR_QuKuai_Markdown_BianJiQi_QuKuai.forEach((item) => {
					if (item.LeiXing == 'P') { NeiRong = NeiRong + `<p>${item.NeiRong}<p>`; }
					if (item.LeiXing == 'H1') { NeiRong = NeiRong + `<h1>${item.NeiRong}</h1>`; }
					if (item.LeiXing == 'H2') { NeiRong = NeiRong + `<h2>${item.NeiRong}</h2>`; }
					if (item.LeiXing == 'H3') { NeiRong = NeiRong + `<h3>${item.NeiRong}</h3>`; }
					if (item.LeiXing == 'H4') { NeiRong = NeiRong + `<h4>${item.NeiRong}</h4>`; }
					if (item.LeiXing == 'H5') { NeiRong = NeiRong + `<h5>${item.NeiRong}</h5>`; }
					if (item.LeiXing == 'H6') { NeiRong = NeiRong + `<h6>${item.NeiRong}</h6>`; }
					if (item.LeiXing == 'YinYong') { NeiRong = NeiRong + `<blockquote>${item.NeiRong}</blockquote>`; }
					if (item.LeiXing == 'DaiMa') { NeiRong = NeiRong + `<pre><code>${item.NeiRong}</code></pre>`; }
					if (item.LeiXing == 'LieBiao') { NeiRong = NeiRong + `<li>${item.NeiRong}</li>`; }
					if (item.LeiXing == 'TuPian') { NeiRong = NeiRong + `<p><img src="${item.NeiRong}"></p>`; }
					if (item.LeiXing == 'ShiPin') { NeiRong = NeiRong + `<p><video src="${item.NeiRong}" controls="controls"></video></p>`; }
				})
				// 本地同步储存，key 是 LinShi_ZhengWen_NeiRong，可以自由更改
				uni.setStorageSync("LinShi_ZhengWen_NeiRong", NeiRong);
				uni.getStorage({
					key: "LinShi_ZhengWen_NeiRong",
					success: function (res) {
						console.log(res.data);
					}
				});
				// 触发全局的自定义事件，通知上一页，key 是 emit_LinShi_ZhengWen_NeiRong，可以自由更改
				uni.$emit('emit_LinShi_ZhengWen_NeiRong');
				
				// 返回上一页
				uni.navigateBack();
			},
			
			// 这里是生成 uuid 的方法，用做生成本页面的唯一ID
			uuid() {
				let s = [];
				let hexDigits = "0123456789abcdef";
				for (let i = 0; i < 36; i++) {
					s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
				}
				s[14] = "4";
				s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);
				s[8] = s[13] = s[18] = s[23] = "-";

				let uuid = s.join("");
				return uuid;
			},
		},
		// 返回逻辑，处理 手机返回键
		onBackPress(e) {
			if (e.from == 'backbutton') {
				this.DianJi_QueRen_BianJi();
				return true; // 禁止返回
			}
			// 如果是uni.navigateBack()事件，则直接返回，通常都是发布成功以后调用
			if (e.from == 'navigateBack') {
				return false;
			}
		},
		// 生命周期 -> 监听页面卸载
		onUnload() {
			// 只在微信小程序中执行，微信小程序是不支持 onBackPress ，只能用 onUnload 解决
			// #ifdef MP-WEIXIN
				this.DianJi_QueRen_BianJi();
			// #endif
		},
	}
</script>

<style lang="scss">
$HuangSe:#ffe60f;
$LvSe:#67C23A;
$JuHuang:#E6A23C;
$HongSe:#F56C6C;
$LanSe:#409EFF;
// 字体颜色
$YuanSe:#303133;
$ChangGuiSe:#606266;
$FuZhuSe:#909399;
$ZhanWeiSe:#C0C4CC;
// 边框色
$BianKuangSe:#EBEEF5;
// 背景色
$BeiJingSe:#F5F7FA;
view,textarea{
	font-size:28rpx;
	color: $YuanSe;
	line-height:40rpx;
	box-sizing: border-box;
}
textarea,editor,form,input,editor{
	display: block;
}
image{
	display: block;
}
.ZhuangTaiLan-GaoDu{
	height: var(--status-bar-height);
}
@keyframes XunHuan{
	0%{opacity:0}
	100%{opacity:1}
}
.XunHuan{
	animation-name:XunHuan;
	animation-duration: .8s;
	animation-fill-mode: both;
}
page{background: $BeiJingSe;}
.index{
	.QuKuai{
		margin-bottom: 25rpx;
		border-top: 1rpx solid $BianKuangSe;
		.textarea{
			textarea{
				background: #FFF;
				font-size: 28rpx;
				padding: 25rpx;
				width: 750rpx;
			}
			.textarea-P{
				display: flex;
			}
			.textarea-P:before {
				content: "<p>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-right: 15rpx;
			}
			
			.textarea-P::after {
				content: "</p>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-left: 15rpx;
				display: flex;
				align-items: flex-end;
			}
			.textarea-H1{
				display: flex;
			}
			.textarea-H1:before {
				content: "<h1>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-right: 15rpx;
			}
			.textarea-H1::after {
				content: "</h1>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-left: 15rpx;
				display: flex;
				align-items: flex-end;
			}
			
			.textarea-H2{
				display: flex;
			}
			.textarea-H2:before {
				content: "<h2>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-right: 15rpx;
			}
			.textarea-H2::after {
				content: "</h2>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-left: 15rpx;
				display: flex;
				align-items: flex-end;
			}
			
			.textarea-H3{
				display: flex;
			}
			.textarea-H3:before {
				content: "<h3>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-right: 15rpx;
			}
			.textarea-H3::after {
				content: "</h3>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-left: 15rpx;
				display: flex;
				align-items: flex-end;
			}
			
			.textarea-H4{
				display: flex;
			}
			.textarea-H4:before {
				content: "<h4>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-right: 15rpx;
			}
			.textarea-H4::after {
				content: "</h4>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-left: 15rpx;
				display: flex;
				align-items: flex-end;
			}
			
			.textarea-H5{
				display: flex;
			}
			.textarea-H5:before {
				content: "<h5>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-right: 15rpx;
			}
			.textarea-H5::after {
				content: "</h5>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-left: 15rpx;
				display: flex;
				align-items: flex-end;
			}
			
			.textarea-H6{
				display: flex;
			}
			.textarea-H6:before {
				content: "<h6>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-right: 15rpx;
			}
			.textarea-H6::after {
				content: "</h6>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-left: 15rpx;
				display: flex;
				align-items: flex-end;
			}
			.textarea-YinYong{
				display: flex;
			}
			.textarea-YinYong:before {
				content: "<blockquote>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-right: 15rpx;
			}
			.textarea-YinYong::after {
				content: "</blockquote>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-left: 15rpx;
				display: flex;
				align-items: flex-end;
			}
			.textarea-DaiMa{
				display: flex;
			}
			.textarea-DaiMa:before {
				content: "<pre><code>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-right: 15rpx;
			}
			.textarea-DaiMa::after {
				content: "</code></pre>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-left: 15rpx;
				display: flex;
				align-items: flex-end;
			}
			.textarea-LieBiao{
				display: flex;
			}
			.textarea-LieBiao:before {
				content: "<li>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-right: 15rpx;
			}
			.textarea-LieBiao::after {
				content: "</li>";
				color: $ZhanWeiSe;
				font-size: 16rpx;
				flex-shrink: 0;
				padding-left: 15rpx;
				display: flex;
				align-items: flex-end;
			}
			.textarea-TuPian{
				width: 100%;
				image{
					display: block;
					width: 100%;
					height: auto;
				}
			}
			.textarea-ShiPin{
				width: 100%;
				video{
					display: block;
					width: 100%;
				}
			}
		}
		.CaoZuoQu{
			background: #FFF;
			display: flex;
			border-top: 1rpx solid $BianKuangSe;
			border-bottom: 1rpx solid $BianKuangSe;
			.icon-arrow-up-filling , .icon-arrow-down-filling , .icon-delete-filling{
				width: 50rpx;
				height: 50rpx;
				display: flex;
				align-items: center;
				justify-content: center;
				font-size: 30rpx;
				border-right: 1rpx solid $BianKuangSe;
				color: $ZhanWeiSe;
			}
			.icon-delete-filling{
				border-right: 0;
				border-left: 1rpx solid $BianKuangSe;
				margin-left: auto;
			}
			.Zi{
				height: 50rpx;
				display: flex;
				align-items: center;
				font-size: 22rpx;
				border-right: 1rpx solid $BianKuangSe;
				color: $ZhanWeiSe;
				padding: 0 15rpx;
			}
		}
		.ChaRuQu {
			width: 700rpx;
			margin: 25rpx 25rpx 0 25rpx;
			height: 60rpx;
			display: flex;
		
			.ChaRuQu-Zuo {
				height: 60rpx;
				display: flex;
				align-items: center;
				color: $ZhanWeiSe;
				font-size: 22rpx;
				flex-shrink: 0;
				width: 65rpx;
			}
		
			.ChaRuQu-Zhong {
				width: 595rpx;
				height: 60rpx;
		
				scroll-view {
					width: 595rpx;
					height: 60rpx;
					border: 1rpx solid $BianKuangSe;
					background: #FFF;
					box-sizing: border-box;
					border-radius: 10rpx;
					overflow: hidden;
		
					.ChaRuQu-Zhong-AnNiu {
						display: flex;
						height: 60rpx;
		
						view {
							padding: 0 20rpx;
							height: 60rpx;
							flex-shrink: 0;
							display: flex;
							align-items: center;
							justify-content: center;
							border-right: 1rpx solid $BianKuangSe;
							color: $ZhanWeiSe;
						}
		
						.TuBiao-Zi {
							font-size: 22rpx;
							line-height: 22rpx;
						}
		
						.iconfont {
							font-size: 30rpx;
							line-height: 30rpx;
						}
		
						view:last-child {
							border-right: 0;
						}
		
						.Hover {
							color: #000;
						}
					}
				}
			}
		
			.ChaRuQu-You {
				width: 40rpx;
				height: 60rpx;
				flex-shrink: 0;
		
				view {
					width: 40rpx;
					height: 60rpx;
					display: flex;
					align-items: center;
					justify-content: flex-end;
					color: $ZhanWeiSe;
					font-size: 22rpx;
				}
			}
		}
	}
	.WeiBu-AnNiu{
		width: 100%;
		height: 80rpx;
		border-top: 1rpx solid $BianKuangSe;
		background: #FFF;
		display: flex;
		align-items: center;
		position: fixed;
		bottom: 0;
		left: 0;
		z-index: 99999999;
		.Zuo{
			height: 80rpx;
			flex: 1;
			display: flex;
			align-items: center;
			.ZuoQingKong{
				color: $HongSe;
				height: 80rpx;
				display: flex;
				align-items: center;
				font-size: 22rpx;
				padding: 0 0 0 25rpx;
			}
			.ZuoTiShi{
				height: 80rpx;
				display: flex;
				align-items: center;
				padding: 0 25rpx;
				color: $ZhanWeiSe;
				font-size: 22rpx;
			}
		}
		.You{
			width: 200rpx;
			height: 80rpx;
			background: $LanSe;
			color: #FFF;
			display: flex;
			align-items: center;
			justify-content: center;
			font-size: 22rpx;
		}
	}
	// 如果没有任何区块显示的
	.RuGuo-MeiYou-QuKuai {
		._TiShi {
			margin: 100rpx 25rpx;
			display: flex;
			align-items: center;
	
			text {
				font-size: 130rpx;
				color: $ZhanWeiSe;
				opacity: .2;
			}
	
			view {
				margin: 0 25rpx 0 15rpx;
				line-height: 40rpx;
				color: $ZhanWeiSe;
			}
		}
	
		._Kuai {
			width: 750rpx;
			display: flex;
			flex-wrap: wrap;
	
			.XunHuan {
				width: 216.666rpx;
				height: 100rpx;
				background: #FFF;
				margin: 25rpx 0 0 25rpx;
				box-sizing: border-box;
				border: 1rpx solid $BianKuangSe;
				border-radius: 10rpx;
				display: flex;
				align-items: center;
				justify-content: center;
				color: $ZhanWeiSe;
				text {
					font-size: 35rpx;
				}
			}
		}
	}
}
@font-face {
  font-family: "iconfont"; /* Project id 3832835 */
  src: 
       url('data:application/x-font-woff2;charset=utf-8;base64,d09GMgABAAAAAAZMAAsAAAAADSAAAAX+AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHFQGYACEGAqLSIk7ATYCJAMoCxYABCAFhGcHgSwbOwsjESZs00D2z4R47KgxZGPjodhoV1GoqvfMFD3XXXQXHd/EA7X26Nvdu38QAtCgEBUQSGKVqCiWmXgClegoQIfQVnX+8O/W3i560CPqIhK9hMsCtIkxI+JNe/ul/2zCqMSLEqz8qvxThmNgNLvuu+ZvHxULFWEO5ewnj76Q9rpC+nLp6P/WWt3Z82bxGrzfthTwGGfORzGzJpru0ZZEyEco4p4Sj1AouWImbvfBrDKzUrI55k8RUBtrkjh56uzFWm9bvW+H7jLCHIiHh22bN65WzgpkFk9Qqgb3yEw4JyeeiQM46/98+GJ8KInyRJxn/oYp6zx6v/RTm3S4CUmvuSYBto7IkTByYEXhgr3ivBTSkT6vTWMzW9Be29n14vvd7/e+v/H+2/v/Pv751PJTm2aTfIqvk4mqoL20dfw3jyBqKJQqSSYnNIC3HNn2s+rShrRB4P3ePJHEDeRpQPxAngLiJ/KUEP/BoOLjH4PEp5YGGZ/aTJCD2j2iI3oSnhJnEnK2T6Pk+e0aVQqC2Huc0VFsPiaLjs5ksRJjWHGsMPrrDAZftp7CzDZSQNgPeBw8E251uuNyruXkOvvdTj5usjg8dPFixvU9yPUAHr8fw6D8J5Fw8tTDWCb94ARYjJDe/Gg3iIdi6UcVQYG9vUvO9Nu8mD+GmpjIl1pOY17ZNxBDJQPo4b+lD1lGjZHj9CgcqaN9pJdyQ89iAN2UF0ECAU0AQUgf7QFg/yO4aW0wmlu7b2JiHhkM0o8eATDuTQUCiBbAWT4dtGOQrg5ZrT105sIREOHh86dTNb3V4/RQHW0D+q32dJ2Npwvttx5HeqWh+5gpr5f0+WLpK/AyETeUslDSZ6Ie26rchlgkZmk+rRlp6dpW41bovkTMe8YpfV7JPo05BvJMFkpPaU6ZkcfJ6C3ZYnkus/WAQNtvPeQjMY3W7nId5PVpbsWekN/fZ4HFx+PRXX3FXpHX6e3cw5HYJ8loLbtYpUXX9Be7RC6w3YZcpYz6OkRFQLECPShp94kQyc7YriwTVcxenVThEKk2p4qA8oQmEP97Zvy8+Jm/40HYt/rlK+wfNk9/p66HXzgzYZaozoBvKW/Of+ZNwBv0f+c3TV6Q19VXFpgV6V95PtgoSsVUBLsjU5G+ukv6N6OJ4nqgyCqL74SWTYu0GTM7srtmYGiihINi3enqNFVdWn3aXoU9HOHkWbsxlCNJRLEZ2V2ZHTZjV7yyXK+vWDHCo3zl9VgrR+Wjq69dT09Tq9J6CNPA9OsZaSpVOl0YTHSYWxSlD03gMbiFobOFRElW/IeZ8dZTYvDkSHiuD/ErnNvVdQciGBHW7jsdEPuCWftNoe5txb6sAOwR7IOOsCX1JWpgOQ06fxHAhwFBaWz1R5HnzwznC4xBQ9Hvpj1CQYp/lVkxiv1AL71ON5C4m32CsytpQBMtC95czPX9X7waV+qVqgz/ogyJv7Tyy2gMmrSa3DmPIF7ZtdkiJ44Tc9YIv0E7QYcSOyFb7MDNBLFWJOXQI6IgbfvCVUlbabvr8Q/NR9maRqTR2eRXuZoSKk7ExdjuWKyh6c+NVPol3cr9YvXMlW0m/C77d7vi3eOmP1TX9BfeYEoRdvArKZYxF802jdSZaWY6/BdQtUT5hiyjlnF8C2vae9u07MAOffdlhxiiQg9ISv1RZhsOuRbGQ0NpItRGmEJbjLbfJQlZhcGOAYK2rkHU2m1I2nqCMtszyHX2ARra+h9q8zThIRaLMwTzxqgELegzBEPFKSV+ot/oW1Jc1PqPvAY0w9SP2e4vLMh17LMe/CziwDFl+JxcD1MiqEx7NNIvInU3DM70Kb2hvHnDkCKQBbQzEBikcO7ikv5935DXJAoz0X8ZW0cBShxMeiMDffHCmnQgY1cH3kyozAFNmboy8DkrQ2ndQUA1t+0hs67oLRXaqp1BLua4vO9e5rs68gufQrxJbYqybMf1fD3Yq5np2FlqOmGnzE5ec3tz8IvcSatBldtzOwd3/GUJmu4z2Rsrnpm7tNq5kFIovmzxsWSHP1pMKJjM32wAAA==') format('woff2');
}

.iconfont {
  font-family: "iconfont" !important;
  font-size: 16px;
  font-style: normal;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.icon-arrow-double-left:before {
  content: "\e671";
}

.icon-arrow-double-right:before {
  content: "\e673";
}

.icon-tupian:before {
  content: "\e8f3";
}

.icon-yuyin:before {
  content: "\e90c";
}

.icon-zhibo:before {
  content: "\e90f";
}

.icon-modular:before {
  content: "\e6b6";
}

.icon-arrow-up-filling:before {
  content: "\e6ef";
}

.icon-arrow-down-filling:before {
  content: "\e6f0";
}

.icon-delete-filling:before {
  content: "\e6f7";
}
</style>