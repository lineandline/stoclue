<template>
	<view class="content">
		<!-- 输入内容 -->
		<view class="u-flex u-p-l-30 u-p-r-10 u-p-b-30">
			<u-form :model="user" ref="uForm">
				<u-form-item label="用户名" label-width="150" prop="username" left-icon="account">
					<u-input placeholder="请输入姓名" v-model="user.username" type="text"></u-input>
				</u-form-item>
				<u-form-item label="密码" label-width="150" left-icon="lock" prop="password">
					<u-input placeholder="请输入密码" v-model="user.password" type="password"></u-input>
				</u-form-item>
				<u-form-item label="记住密码" label-width="150" prop="remember">
					<u-switch v-model="user.remember" slot="right"></u-switch>
				</u-form-item>
			</u-form>
		</view>
		<!-- 登录按钮 -->
		<view>
			<u-button @click="submit">提交</u-button>
		</view>
		<!-- 注册 -->
		<view class="u-demo-wrap">
			<view>
				<u-link color="blue" font-size="20rpx" :under-line="true" :href="href">注册</u-link>
			</view>
		</view>
		<view>
			<u-toast ref="uToast" />
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				//声明一个模型对象  user  由  username、password 、 remember组成
				//模型对象属性必须给初始值  否则可能会出现undifinded异常
				//JavaScript 是弱类型非严谨格式的
				user: {
					username: '',
					password: '',
					remember: false
				},
				href:'/pages/register/register'
			}
		},
		methods: {
			submit:function(){
				// console.log("登录处理....");
				// this.user  表示获取到当前的vue对象中的模型对象(data)里面的user
				// console.log(this.user);
				
				
				uni.request({
					url: 'http://192.168.1.208:8086/user/login', // 服务端提供的登录处理接口地址。
					method:'GET',
					//默认get 转换后 text=uni.request   参数名必须与后台的函数参数名对应
					data: this.user /* {
						username:this.user.username,
						password:this.user.password,
						remember:this.user.remember
					} */ ,
					//成功的处理函数 res为响应结果对象 data为后台返回的数据
					//=> 将vue对象传递到函数中
					success: (res) => {
						// console.log(res.data);
						//在第三方函数调用中，this会被替换成别的对象
						// console.log(this);
						// console.log(this.user);
						if(res.data.success){
							this.$refs.uToast.show({
								title: '登录成功',
								type: 'success'
							})
							//缓存用户信息
							var result = res.data;
							
							//转字符串
							var userStr = JSON.stringify(result.data);
							//setStorage会将数据缓存到硬盘 ，在任意页面都可以获取
							uni.setStorage({
								key: 'loginUser',
								data: userStr,
								success: function () {
									console.log('success');
								}
							});
							//跳转到原页面并刷新页面的数据
							uni.navigateBack();
						}else{
							this.$refs.uToast.show({
								title: '登录失败',
								type: 'fail'
							})
						}
					},
					fail: function(res){
						// console.log(res);
						this.$refs.uToast.show({
							title: res.errMsg,
							type: 'fail'
						})
					}
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.content {
	  padding: 0 60rpx;
	}
	
	
.u-demo-wrap {
	border-width: 1px;
	border-color: #ddd;
	border-style: dashed;
	background-color: rgb(250, 250, 250);
	padding: 20px 10px;
	border-radius: 3px;
	}
</style>