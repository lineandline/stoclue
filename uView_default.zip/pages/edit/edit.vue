<template>
	<view class="uni-container">
		<uni-forms ref="form" v-model="formData"  validateTrigger="bind" @submit="submit">
			<uni-forms-item name="username" label="用户名" required>
				<uni-easyinput v-model="formData.username" :clearable="false" placeholder="请输入用户名" />
			</uni-forms-item>
			<uni-forms-item name="nickname" label="用户昵称" required>
				<uni-easyinput v-model="formData.nickname" :clearable="false" placeholder="请输入用户昵称" />
			</uni-forms-item>
			
			<uni-forms-item name="deptName" label="部门列表" class="flex-center-x">
				<uni-data-checkbox multiple :localdata="depts" v-model="formData.deptName" />
			</uni-forms-item>
			
			<uni-forms-item name="phone" label="手机号">
				<uni-easyinput v-model="formData.phone" :clearable="false" placeholder="请输入手机号" />
			</uni-forms-item>
			<uni-forms-item name="email" label="邮箱">
				<uni-easyinput v-model="formData.email" :clearable="false" placeholder="请输入邮箱" />
			</uni-forms-item>
			<view class="uni-button-group">
				<button style="width: 100px;" type="primary" class="uni-button" @click="submitForm">修改</button>
				<navigator open-type="navigateBack" style="margin-left: 15px;"><button style="width: 100px;" class="uni-button">返回</button></navigator>
			</view>
		</uni-forms>
	</view>
</template>

<script>
	

	export default {
		data() {
			return {
				showPassword: false,
				formData: {
					"username": "",
					"nickname": "",
					"password": undefined,
					"deptName": "",
					"phone": undefined,
					"email": undefined
				},
				depts: [],
				userId:""
			}
		},
		onLoad(e) {
			
		},
		methods: {
			
			
			
			

			/**
			 * 触发表单提交
			 */
			submitForm(form) {
				this.$refs.form.submit();
			},

			/**
			 * 表单提交
			 * @param {Object} event 回调参数 Function(callback:{value,errors})
			 */
			submit(event) {
				/* const {
					value,
					errors
				} = event.detail
				// 表单校验失败页面会提示报错 ，要停止表单提交逻辑
				if (errors) {
					return
				}
				uni.showLoading({
					title: '修改中...',
					mask: true
				}) */

			},

			
			/**
			 * 获取表单数据
			 * @param {Object} id
			 */
			getDetail(id) {
				/* uni.showLoading({
					mask: true
				}) */
				
			}/* , */
			
			// status 对应文字显示
			/* parseUserStatus(status) {
				if (status === 0) {
					return '启用'
				} else if (status === 1) {
					return '禁用'
				} else if (status === 2) {
					return '审核中'
				} else if (status === 3) {
					return '审核拒绝'
				} else if (status === 4) {
					return '已注销'
				} else if (typeof status !== "undefined") {
					return '未知'
				} else {
					return '启用'
				}
			} */
		},
		computed:{
			/* unknownAppidsCom(){
				
			} */
		}
	}
</script>

<style>
	.reset-password-btn {
		/* height: 100%; */
		line-height: 36px;
		color: #007AFF;
		text-decoration: underline;
		cursor: pointer;
	}

	.cancel-reset-password-btn {
		color: #007AFF;
		padding-right: 10px;
		cursor: pointer;
	}
	::v-deep .uni-forms-item__label {
		width: 90px !important;
	}

	.uni-forms-item-flex-center-x {
		display: flex;
		align-items: center;
		flex-wrap: wrap;
	}
</style>

